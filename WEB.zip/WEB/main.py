from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model

app = Flask(__name__)

# Load model đã huấn luyện
model = load_model("model.h5")

@app.route('/')
def index():
    return render_template('trangchu.html')

@app.route('/trangnhapthongtin', methods=['GET', 'POST'])
def nhapthongtin():
    if request.method == 'POST':
        try:
            # Lấy dữ liệu từ form nhập
            data = {key: float(request.form[key]) for key in request.form}

            # Chuyển đổi dữ liệu thành DataFrame (theo đúng định dạng mô hình cần)
            column_names = [
                "age", "sex", "chest_pain", "resting_bp", "cholesterol",
                "fasting_blood_sugar", "ecg_results", "max_heart_rate",
                "exercise_angina", "oldpeak", "slope", "major_vessels", "thal"
            ]
            
            df = pd.DataFrame([data], columns=column_names)

            # Lưu dữ liệu vào session hoặc truyền qua URL (nếu cần)
            prediction = model.predict(df)[0][0]  # Lấy giá trị dự đoán đầu tiên
            ketqua = "Có nguy cơ mắc bệnh tim" if prediction >= 0.5 else "Không có nguy cơ mắc bệnh tim"

            return redirect(url_for('trangxuatketqua', ketqua=ketqua))

        except Exception as e:
            return f"Lỗi khi xử lý dữ liệu: {str(e)}"

    return render_template('trangnhapthongtin.html')

@app.route('/trangxuatketqua', methods=['POST'])
def du_doan():
    try:
        data = {key: float(request.form[key]) for key in request.form}
        column_names = [
            "age", "sex", "chest_pain", "resting_bp", "cholesterol",
            "fasting_blood_sugar", "ecg_results", "max_heart_rate",
            "exercise_angina", "oldpeak", "slope", "major_vessels", "thal"
        ]
        df = pd.DataFrame([data], columns=column_names)

        prediction = model.predict(df)[0][0]
        ketqua = "Có nguy cơ mắc bệnh tim" if prediction >= 0.5 else "Không có nguy cơ mắc bệnh tim"

        return render_template('trangxuatketqua.html', ketqua=ketqua)
    
    except Exception as e:
        return f"Lỗi khi dự đoán: {str(e)}"


if __name__ == '__main__':
    app.run(debug=True)
